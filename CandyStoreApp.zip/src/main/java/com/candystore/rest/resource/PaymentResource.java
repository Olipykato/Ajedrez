package com.candystore.rest.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.candystore.rest.helper.PaymentHelper;
import com.candystore.rest.model.Payment;
import com.candystore.rest.service.PaymentService;
import com.candystore.rest.utilities.ContextUtils;

@Path("/payment")
public class PaymentResource {

	// service
	PaymentService paymentService = new PaymentService();

	// helper
	PaymentHelper paymentHelper = new PaymentHelper();

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createPayment(Payment payment, final @Context HttpHeaders httpHeaders) {
		try {
			String idClaim = httpHeaders.getRequestHeader("idclaim").get(0);
			if (ContextUtils.validateIdClaim(idClaim))        
				return paymentService.createPayment(payment);

			return Response.status(Status.UNAUTHORIZED.getStatusCode()).build();
		} catch (NullPointerException e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).build();
		}
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllPayments(final @Context HttpHeaders httpHeaders) {
		try {
			String idClaim = httpHeaders.getRequestHeader("idclaim").get(0);
			if (ContextUtils.validateIdClaim(idClaim))
				return paymentService.getAllPayments();

			return Response.status(Status.UNAUTHORIZED.getStatusCode()).build();
		} catch (NullPointerException e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).build();
		}
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getPayment(@PathParam("id") Integer id, final @Context HttpHeaders httpHeaders) {
		try {
			String idClaim = httpHeaders.getRequestHeader("idclaim").get(0);
			if (ContextUtils.validateIdClaim(idClaim))
				return paymentService.getPayment(id);

			return Response.status(Status.UNAUTHORIZED.getStatusCode()).build();
		} catch (NullPointerException e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).build();
		}
	}

	@PUT
	// @Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updatePayment(Payment payment, final @Context HttpHeaders httpHeaders) {
		try {
			String idClaim = httpHeaders.getRequestHeader("idclaim").get(0);
			if (ContextUtils.validateIdClaim(idClaim))
				return paymentService.updatePayment(payment);

			return Response.status(Status.UNAUTHORIZED.getStatusCode()).build();
		} catch (NullPointerException e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).entity(e.getMessage()).build();
		}
	}

	@DELETE
	@Path("/{id}")
	public Response deletePayment(@PathParam("id") Integer id, final @Context HttpHeaders httpHeaders) {
		try {
			String idClaim = httpHeaders.getRequestHeader("idclaim").get(0);
			if (ContextUtils.validateIdClaim(idClaim))
				return paymentService.deletePayment(id);

			return Response.status(Status.UNAUTHORIZED.getStatusCode()).build();
		} catch (NullPointerException e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).build();
		}
	}

}
