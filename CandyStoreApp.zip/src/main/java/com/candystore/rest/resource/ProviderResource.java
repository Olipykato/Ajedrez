package com.candystore.rest.resource;

import java.util.Base64;
import java.nio.charset.StandardCharsets;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Context;
import java.sql.SQLException;
import java.lang.NullPointerException;

import com.candystore.rest.utilities.ContextUtils;
import com.candystore.rest.model.Provider;
import com.candystore.rest.dao.ProviderDAO;
import com.candystore.rest.service.ProviderService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.ExpiredJwtException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;


@Path("/providers")
public class ProviderResource {
  
    ProviderService providerService = new ProviderService();
  
  @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createProvider(Provider provider, final @Context HttpHeaders http) {
      try {
       String idClaim = http.getRequestHeader("providers").get(0);
       if(ContextUtils.validateIdClaim(idClaim)) {
         return providerService.createProvider(provider);
       } else {
          return Response.status(Status.UNAUTHORIZED.getStatusCode()).build();  
       }       
      } catch(Exception e) {
        e.printStackTrace();
        return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).build(); //500
      }            
    }
  
  

  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  public Response updateProvider(Provider provider, final @Context HttpHeaders http){
    String idClaim = http.getRequestHeader("providers").get(0); 
    if (ContextUtils.validateIdClaim(idClaim)) {
         return providerService.updateProvider(provider);
    } else {
      return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).build();
    }
  }
  
  
  
   @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(final @Context HttpHeaders http) {
        String idClaim = http.getRequestHeader("providers").get(0);
      if(ContextUtils.validateIdClaim(idClaim)){
        return providerService.getAll();
      } else {
        return Response.status(Status.UNAUTHORIZED.getStatusCode()).build(); 
      }
    }
  
  
   @DELETE
  @Path("/{id}")
    public Response deleteProvider(@PathParam("id") Integer id, final @Context HttpHeaders http) {
        String idClaim = http.getRequestHeader("providers").get(0);
      if(ContextUtils.validateIdClaim(idClaim)){
        return providerService.deleteProvider(id);
      }
      return Response.status(Status.UNAUTHORIZED.getStatusCode()).build(); 
    }
}
  
  
//   @GET
//     @Produces(MediaType.APPLICATION_JSON)
//     public Response getProvider(Integer id, final @Context HttpHeaders http) {
//         String idClaim = http.getRequestHeader("providers").get(0);
//       if(ContextUtils.validateIdClaim(idClaim)){
//         return Response.status(201).entity("Autorizado").build();
//       }
//       return Response.status(Status.UNAUTHORIZED.getStatusCode()).build(); 
//     }
  
  
    
 