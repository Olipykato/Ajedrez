package com.candystore.rest.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.QueryParam;
import com.candystore.rest.model.Order;
import com.candystore.rest.utilities.ContextUtils;
import com.candystore.rest.service.OrderService;


@Path("/order")
public class OrderResource {
  OrderService service = new OrderService();

  @POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createOrder(final @Context HttpHeaders httpHeaders, Order order) 
  {
    String tmp=httpHeaders.getRequestHeader("idClaim").get(0);
    Response rep;
    if(ContextUtils.validateIdClaim(tmp))
    {      
      String result = "create_Order "+ service.createOrder(order);
      rep = Response.status(200).entity(result).build();
    }else
    {
      rep = Response.status(404).entity("No autorizado").build();
    }  
		return rep;
	}
  
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response getOrder(final @Context HttpHeaders httpHeaders, @QueryParam("id")int id)
  {
    String tmp=httpHeaders.getRequestHeader("idClaim").get(0);
    Order order =null;
    Response rep;
    if(ContextUtils.validateIdClaim(tmp))
    {
      order = service.getOrder(id);
      String result = " " + order;
      rep = Response.status(200).entity(result).build();
    }else
    {
      rep = Response.status(404).entity("No autorizado").build();
    }  
		return rep;
	}	

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateOrder(final @Context HttpHeaders httpHeaders, Order order) 
  {
    String tmp=httpHeaders.getRequestHeader("idClaim").get(0);
    boolean orderUpdate;
    Response rep;
    if(ContextUtils.validateIdClaim(tmp))
    { 
      orderUpdate = service.updateOrder(order);
      String result = "update_Order "+orderUpdate;
      rep = Response.status(200).entity(result).build();
    }else
    {
      rep = Response.status(404).entity("No autorizado").build();
    }  
		return rep;
	}

	@DELETE
	@Consumes(MediaType.APPLICATION_JSON)
  public Response deleteOrder(final @Context HttpHeaders httpHeaders, @QueryParam("id")int id)
	{
    String tmp=httpHeaders.getRequestHeader("idClaim").get(0);
    Order order =null;
    Response rep;
    if(ContextUtils.validateIdClaim(tmp))
    {
      if(service.deleteOrder(id)){
        order = service.getOrder(id);            
      }     
      String result = "DELETE " + order;
      rep = Response.status(200).entity(result).build();
    }else
    {
      rep = Response.status(404).entity("No autorizado").build();
    }
  
		return rep;

	}

}
