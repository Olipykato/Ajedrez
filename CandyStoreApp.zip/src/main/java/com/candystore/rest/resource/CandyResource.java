package com.candystore.rest.resource;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.HttpHeaders;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.PathParam;
import com.candystore.rest.model.Candy;
import com.candystore.rest.utilities.ContextUtils;
import com.candystore.rest.service.CandyService;

 
@Path("/candy")
public class CandyResource {
  private CandyService service = new CandyService();
  //CandyService service = new CandyService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCandy(final @Context HttpHeaders httpHeaders) 
  {

    String tmp="";
    Response rep;

    try{
      tmp=httpHeaders.getRequestHeader("idclaim").get(0);
    }catch(Exception e)
    {
      rep = Response.status(500).entity("Server Error").build();
    }
     
    Candy candy =null;
    
        
    if(ContextUtils.validateIdClaim(tmp))
    {

      candy = new Candy();
      candy.setName(httpHeaders.getRequestHeaders().toString());
      System.out.println(" Candy- Get-");
      rep = Response.status(201).entity(candy).build();

    }else
    {

      rep = Response.status(401).entity("No autorizado").build();
    }
    return rep;
	}
  
  @GET
  @Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCandy( final @PathParam("id") int id,  final @Context HttpHeaders httpHeaders) 
  {
    String idClaim = "";
    //Response rep;
   try{

	idClaim = httpHeaders.getRequestHeader("idClaim").get(0);

	}
	catch(Exception e)
	{
	return null;

	}

 
    if(ContextUtils.validateIdClaim(idClaim)){
        /*Candy objetoEncontrado = service.searchCandy(id);
        if(objetoEncontrado != null){
          rep = Response.status(200).entity(objetoEncontrado).build();
        }else{
        rep = Response.status(404).entity("No encontrado").build();
        }*/
        return service.searchCandy(id);
    }else{
      return Response.status(401).entity("No autorizado").build();
    }

  }

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
  //@Produces(MediaType.APPLICATION_JSON)
	public Response createCandy(Candy candy, final @Context HttpHeaders httpHeaders) 
  {
    String idClaim = "";
    //Response rep;
   try{

        idClaim = httpHeaders.getRequestHeader("idClaim").get(0);

        }
        catch(Exception e)
        {
        return null;

        }
    //Response rep;
    
    if(ContextUtils.validateIdClaim(idClaim)){
      return service.addCandy(candy);
      //rep = Response.status(201).entity(service.addCandy(candy)).build();
    }else{
      return Response.status(401).entity("No autorizado").build();
    }
    
    //return rep;
	}
  
  @PUT
  @Path("/{id}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response updateCandy(@PathParam("id") int id, Candy candy, final @Context HttpHeaders httpHeaders)
  {
    String idClaim = "";
    //Response rep;
   try{

        idClaim = httpHeaders.getRequestHeader("idClaim").get(0);

        }
        catch(Exception e)
        {
        return null;

        }
    //Response rep;
    
    if(ContextUtils.validateIdClaim(idClaim)){
      return service.setCandy (id, candy);
      //rep = Response.status(202).entity(service.setCandy(id, candy)).build();
    }else{
      return Response.status(401).entity("No autorizado").build();
      //rep = Response.status(401).entity("No autorizado").build();
    }
     //return rep; 	
  }
  
  /*@DELETE
  @Path("/{id}")
  @Consumes(MediaType.APPLICATION_JSON)
  public Response updateCandy(@PathParam("id") int id, final @Context HttpHeaders httpHeaders)
  {
    String idClaim = "";
    //Response rep;
   try{

        idClaim = httpHeaders.getRequestHeader("idClaim").get(0);

        }
        catch(Exception e)
        {
        return null;

        }
    //Response rep;
    
    if(ContextUtils.validateIdClaim(idClaim)){
      return service.deleteCandy (id);
      //rep = Response.status(202).entity(service.setCandy(id, candy)).build();
    }else{
      return Response.status(401).entity("No autorizado").build();
      //rep = Response.status(401).entity("No autorizado").build();
    }
     //return rep; 	
  }	*/
  /*private String getTokenFromHeader(HttpHeaders httpHeaders) throws NullPointerException {
      return httpHeaders.getRequestHeader("Authorization").substring("Bearer".length()).trim(); 
  }*/
}
