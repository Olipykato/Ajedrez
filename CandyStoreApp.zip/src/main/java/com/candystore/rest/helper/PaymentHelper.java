package com.candystore.rest.helper;

import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

import javax.ws.rs.core.HttpHeaders;

import com.candystore.rest.model.Payment;

public class PaymentHelper {

	/**
	 * Set resulset values in a Payment object
	 * 
	 * @param resultSet
	 * @return Payment object with resulset values
	 * @throws SQLException
	 */
	public Payment createPaymentFromResulset(ResultSet resultSet) throws SQLException {
		Payment payment = new Payment();
		payment.setCardNumber(resultSet.getString("cardNumber"));
		payment.setMonth(resultSet.getInt("month"));
		payment.setYear(resultSet.getInt("year"));
		payment.setCvc(resultSet.getInt("cvc"));
		payment.setNameInCard(resultSet.getString("nameInCard"));
		payment.setIdPaymentType(resultSet.getInt("idPaymentType"));
		return payment;
	}

	/**
	 * Check null in payment values
	 * 
	 * @param payment
	 * @param withId
	 * @return
	 */
	public boolean isValidPayment(Payment payment, boolean withId) {
		try {
			if (withId)
				payment.getId().toString();

			payment.getCardNumber().toString();
			payment.getMonth().toString();
			payment.getYear().toString();
			payment.getCvc().toString();
			payment.getNameInCard().toString();
			payment.getIdPaymentType().toString();

			return true;
		} catch (NullPointerException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 
	 * @param httpHeaders
	 * @return
	 * @throws NullPointerException
	 */
	public String[] getCredentialsFromHeader(HttpHeaders httpHeaders) throws NullPointerException {
		String encodedAuthorizationHeaders = httpHeaders.getRequestHeader("Authorization").get(0);
		String encodedCredentials = encodedAuthorizationHeaders.substring("Basic".length()).trim();
		String decodedCredentials = new String(Base64.getDecoder().decode(encodedCredentials), StandardCharsets.UTF_8);
		return decodedCredentials.split(":", 2);
	}

	/**
	 * 
	 * @param httpHeaders
	 * @return
	 * @throws NullPointerException
	 */
	public String getTokenFromHeader(HttpHeaders httpHeaders) throws NullPointerException {
		return httpHeaders.getRequestHeader("Authorization").get(0).substring("Bearer".length()).trim();
	}

}