package com.candystore.rest.dao.daoInterface;

public interface Item {
	String getName();
	int getPrice(String name);
}