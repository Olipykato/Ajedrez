package com.candystore.rest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.candystore.rest.helper.PaymentHelper;
import com.candystore.rest.model.Payment;
import com.candystore.rest.utilities.DBConnectionPool;

public class PaymentDao {

	private Connection connection;
	private PreparedStatement statement;
	private ResultSet resultSet;
	private String query;

	// Helper
	PaymentHelper paymentHelper = new PaymentHelper();

	/**
	 * Add new payment
	 * 
	 * @param payment
	 * @return
	 */
	public String add(Payment payment)
  {
		try {
			query = "INSERT INTO Payment(cardNumber, month, year, cvc, nameInCard, idPaymentType) VALUES(?, ?, ?, ?, ?, ?) ";

			connection = DBConnectionPool.getConnection();
			statement = connection.prepareStatement(query);

			statement.setString(1, payment.getCardNumber());
			statement.setInt(2, payment.getMonth());
			statement.setInt(3, payment.getYear());
			statement.setInt(4, payment.getCvc());
			statement.setString(5, payment.getNameInCard());
			statement.setInt(6, payment.getIdPaymentType());

			statement.executeUpdate();

			connection.close();
			statement.close();
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}

	/**
	 * Get list of all payments
	 * 
	 * @return
	 */
	public List<Payment> getAll() {
		List<Payment> payments = null;
		Payment payment = null;
		try {
			query = "SELECT * FROM Payment";

			connection = DBConnectionPool.getConnection();
			statement = connection.prepareStatement(query);
			resultSet = statement.executeQuery();
			//resultSet.beforeFirst();

			payments = new ArrayList<>();
			while (resultSet.next()) {
        payment = new Payment();
        payment.setId(resultSet.getInt("id"));
        payment.setCardNumber(resultSet.getString("cardNumber"));
        payment.setMonth(resultSet.getInt("month"));
        payment.setYear(resultSet.getInt("year"));
        payment.setCvc(resultSet.getInt("cvc"));
        payment.setNameInCard(resultSet.getString("nameInCard"));
        payment.setIdPaymentType(resultSet.getInt("idPaymentType"));
        
				payments.add(payment);
			}

			connection.close();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return payments;
	}

	/**
	 * Get a specific payment by its ID
	 * 
	 * @param id
	 * @return
	 */
	public Payment get(Integer id) {
		Payment payment = null;
		try {
			query = "SELECT * FROM Payment WHERE id=?";

			connection = DBConnectionPool.getConnection();
			statement = connection.prepareStatement(query);
			statement.setInt(1, id);
			resultSet = statement.executeQuery();
      
			if (resultSet.next()) {
        payment = new Payment();
        payment.setId(resultSet.getInt("id"));
        payment.setCardNumber(resultSet.getString("cardNumber"));
        payment.setMonth(resultSet.getInt("month"));
        payment.setYear(resultSet.getInt("year"));
        payment.setCvc(resultSet.getInt("cvc"));
        payment.setNameInCard(resultSet.getString("nameInCard"));
        payment.setIdPaymentType(resultSet.getInt("idPaymentType"));
      }
				
			connection.close();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return payment;
	}

	/**
	 * Update a specific payment
	 * 
	 * @param payment
	 * @return
	 */
	public Payment update(Payment payment) {
		try {
			query = "UPDATE Payment SET cardNumber=?, month=?, year=?, cvc=?, nameInCard=?, idPaymentType=? WHERE id=?";

			connection = DBConnectionPool.getConnection();
			statement = connection.prepareStatement(query);

			statement.setString(1, payment.getCardNumber());
			statement.setInt(2, payment.getMonth());
			statement.setInt(3, payment.getYear());
			statement.setInt(4, payment.getCvc());
			statement.setString(5, payment.getNameInCard());
      statement.setInt(6, payment.getIdPaymentType());
			statement.setInt(7, payment.getId());

			statement.executeUpdate();
			connection.close();
			statement.close();
			return payment;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Delete payment by ID
	 * 
	 * @param id
	 * @return
	 */
	public boolean delete(int id) {
		try {
			query = "DELETE FROM Payment WHERE id=?";

			connection = DBConnectionPool.getConnection();
			statement = connection.prepareStatement(query);

			statement.setInt(1, id);
			statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

}