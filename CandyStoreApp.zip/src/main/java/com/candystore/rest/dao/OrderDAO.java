package com.candystore.rest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import com.candystore.rest.model.Order;
import com.candystore.rest.utilities.DBConnectionPool;

public class OrderDAO {
  private Connection connection;
  private PreparedStatement statement;
  private ResultSet resultSet;
  private String query;
  
  public boolean createOrder(Order order) {
    query = "INSERT INTO `Order`(idUser, total, status) VALUES (?, ?, ?)";
    try {
      
      connection = DBConnectionPool.getConnection();
      statement = connection.prepareStatement(query); 
      
      statement.setInt(1, order.getIdUser());
      statement.setDouble(2, order.getTotal());
      statement.setInt(3, order.getStatus());
      
      statement.executeUpdate();
      return true;
    } catch (SQLException e) {
      return false;
    }
  }
  
  public List<Order> getAll() {
   query = "SELECT * FROM `Order`";
   try {
      List<Order> lstOrders = new ArrayList<>();
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      
      Order order = null;
      resultSet = statement.executeQuery();
      resultSet.beforeFirst();
      while (resultSet.next()) {              
        order = createOrderFromResultSet();
        lstOrders.add(order);
      }      
      connection.close();
      statement.close();
      return lstOrders;           
    } catch (SQLException e) {
      System.out.println(e.getMessage());
      return null;
    }
  }
  
  public Order getOrder(Integer idOrder) {
    query = "SELECT * FROM `Order` WHERE idOrder = ?";
    try {
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query); 
      statement.setInt(1, idOrder);
      
      Order order = null;
      resultSet = statement.executeQuery();
      resultSet.beforeFirst();
      if (resultSet.next()) {     
        order = createOrderFromResultSet();
      }      
      connection.close();
      statement.close();
      return order;           
    } catch (SQLException e) {
      System.out.println(e.getMessage());
      return null;
    }
  }
  
  public boolean updateOrder(Order order) {
    query = "UPDATE `Order` SET idUser = ?, total = ?, status = ? WHERE idOrder = ?";
    try {  
      
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);      
      
      statement.setInt(1, order.getIdUser());
      statement.setDouble(2, order.getTotal());
      statement.setInt(3, order.getStatus());
      statement.setInt(4, order.getIdOrder());
      
      statement.executeUpdate();
      return true;           
    } catch (SQLException e) {
      return false;
    }
  }
  
  public boolean deleteOrder(int idOrder) {
    query = "DELETE FROM `Order` WHERE idOrder = ?";
    try {
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      
      statement.setInt(1, idOrder);
      
      statement.executeUpdate();
      return true;           
    } catch (SQLException e) {
      return false;
    }
  }
  
  private Order createOrderFromResultSet() throws SQLException {
    Order order = new Order();
    order.setIdOrder(resultSet.getInt("idOrder"));
    order.setIdUser(resultSet.getInt("idUser"));
    order.setTotal(resultSet.getDouble("total"));
    order.setStatus(resultSet.getInt("status"));
    return order;
  }
}
