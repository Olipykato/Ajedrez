package com.candystore.rest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.lang.NullPointerException;
import java.util.List;
import java.util.ArrayList;
import com.candystore.rest.utilities.DBConnectionPool;
import com.candystore.rest.model.Provider;


public class ProviderDAO {
  private Connection connection;
  private PreparedStatement statement;
  private ResultSet resultSet;
  private String query;
  
  
  
  public String createProvider(Provider provider) {
    query = "INSERT INTO Provider (name, email, phone, idAddress) VALUES (?, ?, ?, ?)";
    try {
      connection = DBConnectionPool.getConnection();
      statement = connection.prepareStatement(query); 
      
      statement.setString(1, provider.getName());
      statement.setString(2, provider.getEmail());
      statement.setString(3, provider.getPhone());
      statement.setInt(4, provider.getIdAddress());
           
      statement.executeUpdate();
      return null;
    } catch (SQLException e) {
      e.printStackTrace();
      return e.getMessage();
    }
  }
    
  
  public boolean updateProvider(Provider provider) {
    query = "UPDATE Provider SET name = ?, phone = ?, email = ? WHERE id = ?";
    try {      
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      
      statement.setString(1, provider.getName());
      statement.setString(2, provider.getPhone());
      statement.setString(3, provider.getEmail());
      statement.setInt(4, provider.getId());
      statement.executeUpdate();
      return true;           
    } catch (SQLException e) {
      return false;
    }
  }

  
  public List<Provider> getAll() {
    List<Provider> providers = null;
    Provider provider = null;
    
    try {
      query = "SELECT * FROM Provider";
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      resultSet = statement.executeQuery();
     
      providers = new ArrayList<>();
      
       while (resultSet.next()) {    
        provider = new Provider();
        provider.setId(resultSet.getInt("id"));
        provider.setName(resultSet.getString("name"));
        provider.setEmail(resultSet.getString("email"));
        provider.setPhone(resultSet.getString("phone"));
        providers.add(provider);
       }      
       connection.close();
       statement.close();
       return providers;           
     } catch (SQLException e) {
       System.out.println(e.getMessage());
       return null;
     }
   }
  
  
  public boolean deleteProvider(Integer id) {
      try {
      query = "DELETE FROM Provider WHERE id = ?";
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      statement.setInt(1, id);
      statement.executeUpdate();
      return true;           
    } catch (SQLException e) {
      e.printStackTrace();
      return false;
    }
  }
  
  }
  
  /* public Provider getProvider(Integer id) {
    Provider provider = null;
    try {
      query = "SELECT * FROM Provider WHERE id = ?";
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query); 
      statement.setInt(1, id);
      resultSet = statement.executeQuery();
      
    if (resultSet.next()) {
        provider = new Provider();
        provider.setId(resultSet.getInt("id"));
        provider.setName(resultSet.getString("name"));
        provider.setEmail(resultSet.getString("email"));
        provider.setPhone(resultSet.getString("phone"));
        provider.setIdAddress(resultSet.getInt("IdAddress"));  
      }  
      connection.close();
      statement.close();
              
    } catch (SQLException e) {
      e.printStackTrace();
      
    }
     return provider;
  }*/