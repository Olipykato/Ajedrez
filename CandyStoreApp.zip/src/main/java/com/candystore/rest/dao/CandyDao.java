package com.candystore.rest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import com.candystore.rest.utilities.DBConnectionPool;
import com.candystore.rest.model.Provider;
import com.candystore.rest.model.Address;
import com.candystore.rest.model.Candy;



public class CandyDao {
  private Connection connection;
  private PreparedStatement statement;
  private ResultSet resultSet;
  private String query;
  
  public List<Candy> getAll() {
   query = "SELECT * FROM Candies";
   try {
      ArrayList<Candy> candies = new ArrayList<>();
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      
      Candy candy = null;
      resultSet = statement.executeQuery();
      //resultSet.beforeFirst();
      while (resultSet.next()) {                             
        //candy = createCandyFromResultSet();
        candy = new Candy();
        candy.setId(resultSet.getInt("id"));
        candy.setName(resultSet.getString("name"));
        candy.setDescription(resultSet.getString("description"));
        candy.setPrice(resultSet.getDouble("price"));
        candies.add(candy);
      }
      connection.close();
      statement.close();
      return candies;           
      //return null;
    } catch (SQLException e) {
      System.out.println(e.getMessage());
      return null;
    }
  }
  
  public Candy get(int id) {
    query = "SELECT * FROM Candies WHERE id = ?";
    try {
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query); 
      statement.setInt(1, id);
      
      Candy candy = null;
      resultSet = statement.executeQuery();
      resultSet.beforeFirst();
      if (resultSet.next()) {                             
      candy = createCandyFromResultSet();
      }      
      connection.close();
      statement.close();
      return candy;           
    } catch (SQLException e) {
      System.out.println(e.getMessage());
      return null;
    }
  }
  
  public boolean add(Candy candy) {
    query = "INSERT INTO Candies (name,description,price) VALUES (?, ?, ?)";
    try {
      connection = DBConnectionPool.getConnection();
      statement = connection.prepareStatement(query); 
      
      statement.setString(1, candy.getName());
      statement.setString(2, candy.getDescription());
      statement.setDouble(3, candy.getPrice());

      statement.executeUpdate();
      statement.close();
      connection.close();
      return true;
    } catch (SQLException e) {
      return false;
    }    
  }
  
  public boolean update(int id, Candy candy) {
    query = "UPDATE Candies SET name = ?, description = ?, price = ?, WHERE id = ?";
    try {      
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      
      statement.setString(1, candy.getName());
      statement.setString(2, candy.getDescription());
      statement.setDouble(3, candy.getPrice());
      statement.setInt(4, id);
      statement.executeUpdate();
      statement.close();
      connection.close();
      return true;           
    } catch (SQLException e) {
      return false;
    }
  }
  
  public boolean delete(int id) {
   try {
      query = "DELETE FROM Candies WHERE id = ?";
     
     connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      
      statement.setInt(1, id);
      statement.executeUpdate();
      statement.close();
      connection.close();
      return true;           
    } catch (SQLException e) {
      return false;
    }
  }
  
 private Candy createCandyFromResultSet() throws SQLException {
    Candy candy = new Candy();
    candy.setId(resultSet.getInt("id"));
    candy.setName(resultSet.getString("name"));
    candy.setDescription(resultSet.getString("description"));
   candy.setPrice(resultSet.getDouble("price"));
    return candy;
  }
}
