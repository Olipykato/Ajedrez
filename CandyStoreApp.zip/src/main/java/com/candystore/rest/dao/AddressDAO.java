package com.candystore.rest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import com.candystore.rest.utilities.DBConnectionPool;
import com.candystore.rest.model.Address;

public class AddressDAO
{
  private Connection connection;
  private PreparedStatement statement;
  private ResultSet resultSet;
  private String query;
  
  public int add(Address address) throws SQLException 
  {
    query = "INSERT INTO Addresses (street, interiorNumber, exteriorNumber, city, state, zipCode) VALUES (?, ?, ?, ?, ?, ?)";
    connection = DBConnectionPool.getConnection();
    statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

    statement.setString(1, address.getStreet());
    statement.setString(2, address.getInteriorNumber());
    statement.setString(3, address.getExteriorNumber() != null ? address.getExteriorNumber() : "");
    statement.setString(4, address.getCity());
    statement.setString(5, address.getState());
    statement.setString(6, address.getZipCode());

    statement.executeUpdate();  

    resultSet = statement.getGeneratedKeys();
    resultSet.next();
    int autoId = resultSet.getInt(1);  

    statement.close();
    connection.close();   
    return autoId;
  }
    
  public Address get(int id)
  {
    query = "SELECT * FROM Addresses WHERE id = ?";
    try {
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query); 
      statement.setInt(1, id);
      
      Address address = null;
      resultSet = statement.executeQuery();
      resultSet.beforeFirst();
      if (resultSet.next()) 
        address = createAddressFromResultSet(); 
      
      connection.close();
      statement.close();
      return address;           
    } catch (SQLException e) {
      System.out.println(e.getMessage());
      return null;
    }
  }
  
  public boolean update(Address address) 
  {
    try
    {
      query = "UPDATE Addresses SET street = ?, interiorNumber = ?, exteriorNumber = ?, city = ?, state = ?, zipCode = ? WHERE id = ?";
      connection = DBConnectionPool.getConnection();
      statement = connection.prepareStatement(query);

      statement.setString(1, address.getStreet());
      statement.setString(2, address.getInteriorNumber());
      statement.setString(3, address.getExteriorNumber());
      statement.setString(4, address.getCity());
      statement.setString(5, address.getState());
      statement.setString(6, address.getZipCode());
      statement.setInt(7, address.getId());

      statement.executeUpdate();

      statement.close();
      connection.close();   
      return true;
    } catch (SQLException e) {
      return false;
    }
  }
  
  public boolean delete(int id) 
  {
    try
    {
      query = "DELETE FROM Addresses WHERE id = ?";
      connection = DBConnectionPool.getConnection();
      statement = connection.prepareStatement(query);
      
      statement.setInt(1, id);
      
      statement.executeUpdate();

      statement.close();
      connection.close();   
      return true;
    } catch (SQLException e) {
      return false;
    }
  }
  
  private Address createAddressFromResultSet() throws SQLException
  {
    Address address = new Address();
    address.setId(resultSet.getInt("id"));
    address.setStreet(resultSet.getString("street"));
    address.setExteriorNumber(resultSet.getString("exteriorNumber"));
    address.setInteriorNumber(resultSet.getString("interiorNumber"));
    address.setCity(resultSet.getString("city"));
    address.setState(resultSet.getString("state"));
    address.setZipCode(resultSet.getString("zipCode"));
    return address;
  }
}