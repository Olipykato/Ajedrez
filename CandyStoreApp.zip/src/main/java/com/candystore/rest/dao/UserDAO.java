package com.candystore.rest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.lang.NullPointerException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import com.candystore.rest.utilities.DBConnectionPool;
import com.candystore.rest.model.User;
import com.candystore.rest.model.Address;
import com.candystore.rest.dao.AddressDAO;

public class UserDAO
{
  private Connection connection;
  private PreparedStatement statement;
  private ResultSet resultSet;
  private String query;
  
  public boolean add(User user)
  {
    query = "INSERT INTO Users VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    try 
    {
      AddressDAO addressDAO = new AddressDAO();
      int addressId = addressDAO.add(user.getAddress());
      
      connection = DBConnectionPool.getConnection();
      statement = connection.prepareStatement(query); 
      
      statement.setString(1, user.getPassword());
      statement.setString(2, user.getEmail());
      statement.setString(3, user.getFirstName());
      statement.setString(4, user.getLastName());
      statement.setString(5, user.getPhone());
      statement.setString(6, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
      statement.setString(7, user.getTaxId() != null ? user.getTaxId() : "");
      statement.setInt(8, addressId);

      statement.executeUpdate();
      return true;
    } catch (SQLException e) {
      return false;
    }
  }
  
  public List<User> getAll() 
  {
   query = "SELECT * FROM Users";
   try 
   {
      ArrayList<User> users = new ArrayList<>();
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      
      User user = null;
      resultSet = statement.executeQuery();
      resultSet.beforeFirst();
      while (resultSet.next()) 
      {      
        int addressId = resultSet.getInt("addressId");                        
        Address address = new AddressDAO().get(addressId);
        user = createUserFromResultSet();
        user.setAddress(address);
        users.add(user);
      }      
      connection.close();
      statement.close();
      return users;           
    } catch (SQLException e) {
      System.out.println(e.getMessage());
      return null;
    }
  }
  
  public User get(String email) 
  {
    query = "SELECT * FROM Users WHERE email = ?";
    try 
    {
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query); 
      statement.setString(1, email);
      
      User user = null;
      resultSet = statement.executeQuery();
      resultSet.beforeFirst();
      if (resultSet.next()) 
      {      
        int addressId = resultSet.getInt("addressId");                        
        Address address = new AddressDAO().get(addressId);
        user = createUserFromResultSet();
        user.setAddress(address);
      }      
      connection.close();
      statement.close();
      return user;           
    } catch (SQLException e) {
      System.out.println(e.getMessage());
      return null;
    }
  }
  
  public boolean update(User user) 
  {
    query = "UPDATE Users SET firstName = ?, lastName = ?, phone = ?, taxId = ?, password = ? WHERE email = ?";
    try 
    {      
      (new AddressDAO()).update(user.getAddress());
      
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);
      
      statement.setString(1, user.getFirstName());
      statement.setString(2, user.getLastName());
      statement.setString(3, user.getPhone());      
      statement.setString(4, user.getTaxId());
      statement.setString(5, user.getPassword());
      statement.setString(6, user.getEmail());
      
      statement.executeUpdate();
      return true;           
    } catch (SQLException e) {
      return false;
    }
  }
  
  public boolean delete(String email) 
  {
    query = "DELETE FROM Users WHERE email = ?";
    try
    {   
      User user = (new UserDAO()).get(email);
      
      connection = DBConnectionPool.getConnection(); 
      statement = connection.prepareStatement(query);       
      statement.setString(1, email);  
      statement.executeUpdate();
      
      (new AddressDAO()).delete(user.getAddress().getId());
        
      return true;           
    } catch (SQLException | NullPointerException e) {
      return false;
    }
  }
  
  private User createUserFromResultSet() throws SQLException
  {
    User user = new User();
    user.setEmail(resultSet.getString("email"));
    user.setPassword(resultSet.getString("password"));
    user.setFirstName(resultSet.getString("firstName"));
    user.setLastName(resultSet.getString("lastName"));
    user.setPhone(resultSet.getString("phone"));
    user.setTaxId(resultSet.getString("taxId"));
    return user;
  }
}