package com.candystore.rest.utilities;

import java.util.Properties;

import com.candystore.rest.model.User;

public class EmailFactory 
{
	
}