package com.candystore.rest.utilities;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;


public class DBConnectionPool 
{
  private static BasicDataSource dataSource;

  static 
  {
    dataSource = new BasicDataSource();
    dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
    dataSource.setUrl("jdbc:mysql://localhost:3306/hclrestdb");
    dataSource.setUsername("hclRestUser");
    dataSource.setPassword("hcl4rest");

  } 
  

  public static Connection getConnection() throws SQLException 
  {
      return dataSource.getConnection();
  }
  
}

