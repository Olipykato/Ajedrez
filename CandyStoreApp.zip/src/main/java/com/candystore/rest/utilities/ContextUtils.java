package com.candystore.rest.utilities;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;

import java.util.Date;


public class ContextUtils 
{
  public static  boolean validateIdClaim(String idClaim)
  {

    String tmpIdClaim="prueba";

    if(tmpIdClaim.equals(idClaim))
      {
       return true; 
      } 
    
    return false; 

  }
//     private static final String SECRET_KEY;
//     private static final String ISSUER;
//     private static final long TIME_TO_LIVE_IN_MILLIS;
//     private static final int SECRET_KEY_LENGTH;
  
//    static {
//      SECRET_KEY_LENGTH = 128;
//      TIME_TO_LIVE_IN_MILLIS = 60000;
//      ISSUER = "HCLCandyStore";
//      SECRET_KEY = PasswordFactory.generateSecureRandom(128);
//    }
      
//    public static String generateJWTokenFor(String subject) {
//      SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;        
//      byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(SECRET_KEY);
//      Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());
//      long nowMillis = System.currentTimeMillis();
//      Date now = new Date(nowMillis);
//      Date expiration = new Date(nowMillis + TIME_TO_LIVE_IN_MILLIS);
        
//      JwtBuilder builder = Jwts.builder()
//      .setIssuedAt(now)
//      .setSubject(subject)
//      .setIssuer(ISSUER)
//      .signWith(signatureAlgorithm, signingKey)
//      .setExpiration(expiration);

//      return builder.compact();
//     }

//     public static Claims decodeJWToken(String jwtoken) {
//         Claims claims = Jwts.parser()
//                 .setSigningKey(DatatypeConverter.parseBase64Binary(SECRET_KEY))
//                 .parseClaimsJws(jwtoken).getBody();
//         return claims;
//     }
 
}