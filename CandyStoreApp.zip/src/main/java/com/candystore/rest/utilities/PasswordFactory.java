package com.candystore.rest.utilities;

import java.math.BigInteger;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.NoSuchAlgorithmException;

public class PasswordFactory 
{
  
	private static final int ITERATIONS = 1000;
	private static final int KEY_LENGTH_IN_BITS = 256;
	private static final int SALT_LENGTH_IN_BYTES = 32;
	
  private PasswordFactory() {}
  
	public static String generateNewHashFrom(String password) 
  {
		String salt = generateSecureRandom(SALT_LENGTH_IN_BYTES);
		String hashedPassword = generateHash(password, salt);
		return hashedPassword + ":" + salt;
	}
	
	public static String getHashOf(String password, String salt) 
  {
		return generateHash(password, salt);
	}
	  
	public static String generateSecureRandom(int length) 
  {
		SecureRandom random = new SecureRandom();
		byte bytes[] = new byte[length];
		random.nextBytes(bytes);
		return String.format("%x", new BigInteger(bytes));
	}
	  
	private static String generateHash(String password, String salt) 
  {
		char[] passwordChars = password.toCharArray();
		byte[] saltBytes = salt.getBytes();
		
		PBEKeySpec spec = new PBEKeySpec
      (
				passwordChars,
				saltBytes,
				ITERATIONS,
				KEY_LENGTH_IN_BITS
	  	);		
		
		try 
    {
			SecretKeyFactory key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			byte[] hashedPassword = key.generateSecret(spec).getEncoded();
			return String.format("%x", new BigInteger(hashedPassword));
		} catch (NoSuchAlgorithmException |  InvalidKeySpecException e){
			return null; // it won't enter here, PBKDF2WithHmacSHA256 is valid algorithm 
		}		
	} 
}
