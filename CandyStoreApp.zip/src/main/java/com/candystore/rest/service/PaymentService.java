package com.candystore.rest.service;

import java.util.List;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.candystore.rest.dao.PaymentDao;
import com.candystore.rest.helper.PaymentHelper;
import com.candystore.rest.model.Payment;

public class PaymentService 
{
	// dao
	private PaymentDao paymentDao = new PaymentDao();

	// helper
	private  PaymentHelper paymentHelper = new PaymentHelper();

	/**
	 * Logic to create a payment
	 * 
	 * @param payment
	 * @return
	 */
	public Response createPayment(Payment payment) 
  {
	  if(!paymentHelper.isValidPayment(payment, false))
    {
      return Response.status(Status.BAD_REQUEST.getStatusCode()).build();
    }
		
    String tmp = paymentDao.add(payment);
    
		if (tmp == null)
    {
      return Response.status(Status.CREATED.getStatusCode()).build();
    }

		return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).entity(tmp).build();
	}
  
  /**
	 * To test...
	 * 
	 * @param payment
	 * @return
	 */
	public boolean createPayment_toTest(Payment payment) {
		if (!paymentHelper.isValidPayment(payment, false))
			return false;

		if (paymentDao.add(payment) == null)
			return true;

		return false;
	}
  

	/**
	 * Logic to get all payments
	 * 
	 * @return Response OK
	 */
	public Response getAllPayments() {
		List<Payment> payments = paymentDao.getAll();
		if (payments == null)
			return Response.status(Status.NO_CONTENT.getStatusCode()).entity("There are 0 payments").build();

		return Response.status(Status.OK.getStatusCode()).entity(payments).build();
	}
  
  /**
	 * To test
	 * 
	 * @return Response OK
	 */
	public List<Payment> getAllPayments_toTest() {
		return paymentDao.getAll();
	}

	/**
	 * Logic to get a payment by id
	 * 
	 * @param id
	 * @return Response
	 */
	public Response getPayment(Integer id) {
		Payment payment = paymentDao.get(id);
		if (payment == null)
			return Response.status(Status.NOT_FOUND.getStatusCode()).entity("Payment Not Found").build();

		//return Response.status(Status.OK.getStatusCode()).entity(paymentDao.get(id)).build();
    return Response.status(Status.OK.getStatusCode()).entity(payment).build();
	}
  
  /**
	 * To test...
	 * 
	 * @param id
	 * @return Response
	 */
	public Payment getPayment_toTest(Integer id) {
		return paymentDao.get(id);
	}

	/**
	 * 
	 * @param payment
	 * @return
	 */
	public Response updatePayment(Payment payment) {
		if (payment != null) {
			if (paymentDao.update(payment) != null)
				return Response.status(Status.OK.getStatusCode()).entity("Payment Updated").build();
			else
				return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).build();
		}
		return Response.status(Status.BAD_REQUEST.getStatusCode()).entity("Request malformed").build();
	}
  
  /**
	 * To test
   
	 * @param payment
	 * @return
	 */
	public boolean updatePayment_toTest(Payment payment) {
		if (payment != null) {
			return (paymentDao.update(payment) != null) ? true : false;	
		}
		return false;
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public Response deletePayment(Integer id) {
		if (paymentDao.delete(id))
			return Response.status(Status.OK.getStatusCode()).entity("User Deleted").build();
		else
			return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).entity("Delete Error").build();
	}

  /**
	 * To test
   
	 * @param id
	 * @return
	 */
	public boolean deletePayment_toTest(Integer id) {
		return paymentDao.delete(id);
	}

}
