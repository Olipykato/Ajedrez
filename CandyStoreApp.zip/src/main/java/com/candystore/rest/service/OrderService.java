package com.candystore.rest.service;

import com.candystore.rest.dao.OrderDAO;
import com.candystore.rest.model.Order;

public class OrderService
{
  
  OrderDAO orderDao = new OrderDAO();
  
  public OrderService(){}
  
  public Order createOrder(Order order)
  {
	  if(orderDao.createOrder(order))
		  return order;
	  return null;
  } 
  
  public Order getOrder(Integer idOrder)
  {
     return orderDao.getOrder(idOrder);
  }
  
  public boolean updateOrder(Order order)
  {      
	  if(orderDao.updateOrder(order))
		  return true;
	  return false;
  }
  
  public boolean deleteOrder(Integer idOrder)
  {
	  if(orderDao.deleteOrder(idOrder)){
      return true;
    }		  
	  return false;
  }
  
}