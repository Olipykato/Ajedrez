package com.candystore.rest.service;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.util.List;
import java.util.ArrayList;

import com.candystore.rest.dao.ProviderDAO;
import com.candystore.rest.model.Provider;

public class ProviderService {
  
  ProviderDAO providerDao = new ProviderDAO();
  
  //POST
  public Response createProvider(Provider provider) {
    String tmp = providerDao.createProvider(provider);
    if(tmp == null) {
      return Response.status(Status.CREATED.getStatusCode()).build();
    } else {
      return Response.status(Status.BAD_REQUEST.getStatusCode()).entity(tmp).build();
    }
  }
 
  //PUT  
  public Response updateProvider(Provider provider) {
    if(providerDao.updateProvider(provider)) {
      return Response.status(Status.OK.getStatusCode()).build();
    } else {
      return Response.status(Status.BAD_REQUEST.getStatusCode()).build();
    }
  }

  //GET ALL
    public Response getAll() {
      List<Provider> providerList = providerDao.getAll();
      if(providerList!=null) {
        return Response.status(Status.OK.getStatusCode()).entity(providerList).build();
      } else {
        return Response.status(Status.BAD_REQUEST.getStatusCode()).entity("There are no providers in the List!").build(); 
      }
     }

  //DELETE
   public Response deleteProvider(Integer id) {
     if(providerDao.deleteProvider(id)) {
       return Response.status(Status.OK.getStatusCode()).build();
     } else {
       return Response.status(Status.BAD_REQUEST.getStatusCode()).build();
     }
   }

 /*  //GET BY ID
    public Provider getProvider(Integer id) {
    String provider = providerDao.getProvider(id);
    return providerList.get(id);          
=======
  
  
/* //GET BY ID
  public Response getProvider(Integer id) 
  {
    Provider provider = providerDao.getProvider(id);
    if (provider!=null) 
    {
      return Response.status(Status.OK.getStatusCode()).entity(provider).build(); 
      
    } else 
    {
        return Response.status(Status.NOT_FOUND.getStatusCode()).entity("Payment has not been found").build();
>>>>>>> a06459938bab49426dc7d7c484de51d54b1dacc3
    }
           
 } */
 
  
	   
	}
