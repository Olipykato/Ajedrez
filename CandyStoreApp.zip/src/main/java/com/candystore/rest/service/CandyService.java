package com.candystore.rest.service;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


import com.candystore.rest.model.Candy;
import com.candystore.rest.dao.CandyDao;
public class CandyService {
	List<Candy> candyList;
  CandyDao candyDao = new CandyDao();
  
  //List<String> miLista = new ArrayList<String>(); pregunta de caro
  
 public CandyService() {
   candyList = new ArrayList<Candy>();
   candyList.add(new Candy(0, "pulparindo", "de la rosa", 45));
   candyList.add(new Candy(1, "pulparindo3", "de la rosa", 45));
   candyList.add(new Candy(2, "pulparindo2", "de la rosa", 45));
 }
  
  public Response/*List<Candy>*/ getAllCandies()
	{
    candyList = candyDao.getAll();
    //String msg = candyDao.getAll();
    if(candyList!=null){
      return Response.status(Status.OK.getStatusCode()).entity(candyList).build();
    }else{
      return Response.status(Status.BAD_REQUEST.getStatusCode()).build();
    }
		//return candyList;
	}
  
  public Response/*Candy*/ searchCandy(int id) {
		//return candyList.get(id);	
    Candy candy = candyDao.get(id);
    if(candy!=null){
      return Response.status(Status.OK.getStatusCode()).entity(candy).build();
    }else{
      return Response.status(Status.BAD_REQUEST.getStatusCode()).build();
    }
	}
  
	public Response addCandy(Candy objCandy) {
    if(candyDao.add(objCandy)){
      return Response.status(Status.CREATED.getStatusCode()).entity("candy creado").build();
    }else{
      return Response.status(Status.BAD_REQUEST.getStatusCode()).build();
    }
    /*objCandy.setId(candyList.size());
		candyList.add(objCandy);
    System.out.println(candyList);
    return objCandy;*/
	}
  
  public Response setCandy (int id, Candy objCandy) {
    if(candyDao.update(id, objCandy)){
      return Response.status(Status.ACCEPTED.getStatusCode()).entity("candy actualizado").build();
    }else{
      return Response.status(Status.BAD_REQUEST.getStatusCode()).build();
    }
		/*candyList.set(id, objCandy);
    System.out.println(candyList);
    return objCandy;*/
	}
  
  public Response deleteCandy (int id) {
    if(candyDao.delete(id)){
      return Response.status(Status.OK.getStatusCode()).entity("Candy Deleted").build();
    }else{
      return Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).build();
    }
  	
  }
}
