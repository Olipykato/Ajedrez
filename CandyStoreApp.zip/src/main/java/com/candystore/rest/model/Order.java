package com.candystore.rest.model;

public class Order {
	private Integer idOrder;
	private Integer idUser;
	private double total;
	private Integer status;
	
	public Order() {
	}
	
	public Order(Integer idOrder, Integer idUser, double total, Integer status) {
		this.idOrder = idOrder;
		this.idUser = idUser;
		this.total = total;
		this.status = status;
	}
	
	public Integer getIdOrder() {
		return idOrder;
	}
	public void setIdOrder(Integer idOrder) {
		this.idOrder = idOrder;
	}
	public Integer getIdUser() {
		return idUser;
	}
	public void setIdUser(Integer idUser) {
		this.idUser = idUser;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Order [idOrder=" + idOrder + ", idUser=" + idUser + ", total=" + total + ", status=" + status + "]";
	}	
	
}
