package com.candystore.rest.model;

public class OrderDetail {
	private Integer idOrderDetail;
	private Integer idOrder;
	private Integer idProducto;
	private Integer amount;
	private double cost;
	
	public OrderDetail() {
	}

	public OrderDetail(Integer idOrderDetail, Integer idOrder, Integer idProducto, Integer amount, double cost) {
		this.idOrderDetail = idOrderDetail;
		this.idOrder = idOrder;
		this.idProducto = idProducto;
		this.amount = amount;
		this.cost = cost;
	}
	
	public Integer getIdOrderDetail() {
		return idOrderDetail;
	}
	public void setIdOrderDetail(Integer idOrderDetail) {
		this.idOrderDetail = idOrderDetail;
	}
	public Integer getIdOrder() {
		return idOrder;
	}
	public void setIdOrder(Integer idOrder) {
		this.idOrder = idOrder;
	}
	public Integer getIdProducto() {
		return idProducto;
	}
	public void setIdProducto(Integer idProducto) {
		this.idProducto = idProducto;
	}
	public Integer getCantidad() {
		return amount;
	}
	public void setCantidad(Integer amount) {
		this.amount = amount;
	}
	public double getCostoXcantidad() {
		return cost;
	}
	public void setCostoXcantidad(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "OrderDetail [idOrderDetail=" + idOrderDetail + ", idOrder=" + idOrder + ", idProducto=" + idProducto
				+ ", amount=" + amount + ", cost=" + cost + "]";
	}

}
