package com.candystore.rest.model;
//import com.candystore.rest.model.Address;
import java.util.ArrayList;

public class Provider {
  private Integer id;
	private String name;
  private String email;
  private String phone;
  private Integer idAddress;
  //private ArrayList<Candy> candies;
  
 public Provider() {}

  public Provider(Integer id, String name, String email, String phone, Integer idAddress) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.phone = phone;
    this.idAddress = idAddress;
    //this.candies = candies;
   }

  public void setId(Integer id) {
    this.id=id;
  }
	
  
  public Integer getId() {
    return this.id;
  }

  public void setName(String name) {
    this.name=name;
  }
  
  public String getName() {
    return this.name;
  }
  
   public void setEmail(String email) {
    this.email=email;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public void setPhone(String phone) {
    this.phone=phone;
  }
	
  
  public String getPhone() {
    return this.phone;
  }
  
  public void setIdAddress(Integer address) {
  this.idAddress=address;
  }

 public Integer getIdAddress() {
 return this.idAddress;
 }
  
	 @Override
    public String toString() {
        return "Provider [id=" + id + ",name=" + name + ",email="+ email+ ",phone="+ phone+ ",address="+idAddress+ "]";
	}

}