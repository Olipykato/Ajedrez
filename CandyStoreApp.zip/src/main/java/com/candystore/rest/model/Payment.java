package com.candystore.rest.model;

public class Payment {

	private Integer id;
	private String cardNumber;
	private Integer month;
	private Integer year;
	private Integer cvc;
	private String nameInCard;
	private Integer idPaymentType;

	public Payment() {
	}

	public Payment(Integer id, String cardNumber, Integer month, Integer year, Integer cvc, String nameInCard,
			Integer idPaymentType) {
		super();
		this.id = id;
		this.cardNumber = cardNumber;
		this.month = month;
		this.year = year;
		this.cvc = cvc;
		this.nameInCard = nameInCard;
		this.idPaymentType = idPaymentType;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getCvc() {
		return cvc;
	}

	public void setCvc(Integer cvc) {
		this.cvc = cvc;
	}

	public String getNameInCard() {
		return nameInCard;
	}

	public void setNameInCard(String nameInCard) {
		this.nameInCard = nameInCard;
	}

	public Integer getIdPaymentType() {
		return idPaymentType;
	}

	public void setIdPaymentType(Integer idPaymentType) {
		this.idPaymentType = idPaymentType;
	}

	@Override
	public String toString() {
		return "Payment [id=" + id + ", cardNumber=" + cardNumber + ", month=" + month + ", year=" + year + ", cvc="
				+ cvc + ", nameInCard=" + nameInCard + ", idPaymentType=" + idPaymentType + "]";
	}

}
