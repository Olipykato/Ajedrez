package com.candystore.rest.model;

public class DetalleOrden {
	private int idDetalleOrden;
	private int idProducto;
	private int cantidad;
	private int costoXcantidad;

	public DetalleOrden(int idDetalleOrden, int idProducto, int cantidad, int costoXcantidad) {
		this.idDetalleOrden = idDetalleOrden;
		this.idProducto = idProducto;
		this.cantidad = cantidad;
		this.costoXcantidad = costoXcantidad;
	}

	public DetalleOrden() {

	}

	public int getIdDetalleOrden() {
		return idDetalleOrden;
	}

	public void setIdDetalleOrden(int idDetalleOrden) {
		this.idDetalleOrden = idDetalleOrden;
	}

	public int getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public int getCostoXcantdad() {
		return costoXcantidad;
	}

	public void setCostoXcantdad(int costoXcantidad) {
		this.costoXcantidad = costoXcantidad;
	}

}