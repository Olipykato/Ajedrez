package com.candystore.rest.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Address 
{
 
  private Integer id;
  private String street;
  private String exteriorNumber;
  private String interiorNumber;
  private String city;
  private String state;
  private String zipCode;
  
  public Address() {}

  public int getId() {
    return this.id;
  }
  
  public String getStreet() {
    return this.street;
  }
  
  public String getExteriorNumber() {
    return this.exteriorNumber;
  }
  
  public String getInteriorNumber() {
    return this.interiorNumber;
  }
  
  public String getCity() {
    return this.city;
  }
  
  public String getState() {
    return this.state;
  }
  
  public String getZipCode() {
    return this.zipCode;
  }
  
  public void setId(int id) {
    this.id = id; 
  }
  
  public void setStreet(String street) {
    this.street = street;
  }
  
  public void setExteriorNumber(String exteriorNumber) {
    this.exteriorNumber = exteriorNumber;
  }
  
  public void setInteriorNumber(String interiorNumber) {
    this.interiorNumber = interiorNumber;
  }
  
  public void setCity(String city) {
    this.city = city;
  }
  
  public void setState(String state) {
    this.state = state;
  }
  
  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

}