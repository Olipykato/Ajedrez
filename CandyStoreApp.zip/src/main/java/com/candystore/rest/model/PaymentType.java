package com.candystore.rest.model;

public class PaymentType {

	public static int CREDIT_CARD = 1;
	public static int DEBIT_CARD = 2;
	public static int PREPAID_CARD = 3;
	public static int CASH = 4;

}