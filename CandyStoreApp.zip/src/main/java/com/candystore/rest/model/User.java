package com.candystore.rest.model;

import java.util.Date;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class User
{  
	private String email;
  private String password;
	private String firstName;
	private String lastName;
	private String phone;
  private String taxId;
  private Address address;
	private Date joiningDate;
	
  
  public void User() {}
  
  public String getEmail()
  {
    return this.email;
  }
  
  public String getPassword() 
  {
    return password;
  }
  
  public String getFirstName()
  {
    return this.firstName;
  }
  
  public String getLastName()
  {
    return this.lastName;
  }
  
  public String getPhone()
  {
    return this.phone;
  }
  
  public Address getAddress()
  {
    return this.address;
  }
  
  public Date getJoiningDate() 
  {
    return this.joiningDate;
  }
  
  public String getTaxId()
  {
    return this.taxId;
  }
  
  public void setEmail(String email)
  {
    this.email = email;
  }

  public void setPassword(String password) 
  {
    this.password = password;  
  }
  
  public void setFirstName(String firstName)
  {
    this.firstName = firstName;
  }
  
  public void setLastName(String lastName)
  {
    this.lastName = lastName;
  }
  
  public void setPhone(String phone)
  {
    this.phone = phone;
  }
  
  public void setAddress(Address address)
  {
    this.address = address;
  }
  
  public void setJoiningDate(Date joiningDate) 
  {
    this.joiningDate = joiningDate;
  }
  
  public void setTaxId(String taxId)
  {
    this.taxId = taxId;
  }
}
