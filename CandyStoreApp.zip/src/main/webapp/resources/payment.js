const URIpayment = "http://stage.etoolapps.com/candystore4/v1/payment/";
const ID_CLAIM = "08022019-cs";

/**
 * POST
 * 
 * @returns
 */
function addPayment() {
	try {
		const payment = {
			cardNumber : $("#iCardNumber").val(),
			month : $("#iMonth").val(),
			year : $("#iYear").val(),
			cvc : $("#iCvc").val(),
			nameInCard : $("#iNameInCard").val(),
			idPaymentType : $("#cmbPaymentType :selected").val()
		};

		$.ajax({
			url : URIpayment,
			type : 'POST',
			contentType : "application/json; charset=utf-8",
			beforeSend : function(request) {
				request.setRequestHeader("idclaim", ID_CLAIM);
			},
			data : JSON.stringify(payment),
			success : function(data) {
				alert('success');
				$("#showInfo").text("Element saved");
				cleanComponents();
				console.log(data);
			},
			error : function(data) {
				alert('error');
				console.log(data);
			}
		});
	} catch (e) {
		alert('SYSTEM ERROR');
		console.log(e);
	}
}

/**
 * Ini components
 * 
 * @returns
 */
function cleanComponents() {
	$("#iCardNumber").val("");
	$("#iMonth").val("");
	$("#iYear").val("");
	$("#iCvc").val("");
	$("#iNameInCard").val("");
	$("#cmbPaymentType").val(1);
}

/**
 * GET by ID
 * 
 * @returns
 */
function getPayment() {
	try {
		const
		idPayment = $("#input").val();
		$.ajax({
			url : URIpayment + idPayment,
			type : 'GET',
			dataType : "json",
			beforeSend : function(request) {
				request.setRequestHeader("idclaim", ID_CLAIM);
			},
			success : function(data) {
				alert('success');
				console.log(data);
				$("#showInfo").text(data.nameInCard);
        cleanComponents();
			},
			error : function(data) {
				alert('error');
				console.log(data);
			}
		});
	} catch (e) {
		alert('SYSTEM ERROR');
		console.log(e);
	}
}

/**
 * GET All
 * 
 * @returns
 */
function getPayments() {
	try {
		$.ajax({
			url : URIpayment,
			type : 'GET',
			dataType : 'json',
			beforeSend : function(req) {
				req.setRequestHeader("idclaim", ID_CLAIM);
			},
			success : function(data) {
				alert('success');
				console.log(data);
				$("#showInfo").text(data[0].nameInCard);
			},
			error : function(data) {
				alert('error');
				console.log(data);
				$("showInfo").val(data);
			}
		});
	} catch (e) {
		alert("SYSTEM ERROR");
		console.log(e);
	}
}

/**
 * PUT
 * 
 * @returns
 */
function updatePayment() {
  try {
    const payment = {
      id: $("#iId").val(),
			cardNumber : $("#iCardNumber").val(),
			month : $("#iMonth").val(),
			year : $("#iYear").val(),
			cvc : $("#iCvc").val(),
			nameInCard : $("#iNameInCard").val(),
			idPaymentType : $("#cmbPaymentType :selected").val()
		};
    
    $.ajax({
      url: URIpayment,
      type: 'PUT',
      contentType : "application/json; charset=utf-8",
      beforeSend : function(request) {
				request.setRequestHeader("idclaim", ID_CLAIM);
			},
      data : JSON.stringify(payment),
			success : function(data) {
				alert('success');
				$("#showInfo").text("Element updated");
				cleanComponents();
				console.log(data);
			},
			error : function(data) {
				alert('error');
				console.log(data);
			}
    });
  } catch(e) {
    alert("SYSTEM ERROR");
    console.log(e);
  }
}

function deletePayment() {
  try{
    $.ajax({
      url: URIpayment + $("#input").val(),
      type: 'DELETE',
      //dataType: 'json',
      beforeSend: function(req) {
        req.setRequestHeader("idclaim", ID_CLAIM);
      },
      success: function(data) {
        alert("success");
        console.log(data);
      },
      error: function(data) {
        alert("error");
        console.log(data);
      }
    });
  } catch(e) {
    alert("SYSTEM ERROR");
    console.log(e);
  }
}
