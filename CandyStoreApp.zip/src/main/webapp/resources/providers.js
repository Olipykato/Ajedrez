$(document).ready(function () {
    
  $("#btnPost").click(function () {
        $.ajax({
            url: 'http://stage.etoolapps.com/candystore2/v1/providers',
            type: 'POST',
            contentType: "application/json; charset=utf-8",
            //dataType: "json",
            beforeSend : function(request) {
              request.setRequestHeader("providers", "prueba");
            },
            data: JSON.stringify({              
              name:"Jose De La Rosa",
              phone: "33 54321",
              email: "jose@gmail.com",
              idAddress: 1
            }),
            success: function (result) {
                alert('success');
                console.log(result);
            },
            error: function(result) {
                alert('error');
                console.log(result);
            }
        });
    });

   $("#btnGet").click(function () {
        $.ajax({
            url: 'http://stage.etoolapps.com/candystore2/v1/providers',
            type: 'GET',
            //contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend : function(request) {

              request.setRequestHeader("Authorization", "Basic ;) .");
              request.setRequestHeader("MyCustomHeader", "MyCustomHeader.");
              request.setRequestHeader("Access-Control-Allow-Origin", "http://stage.etoolapps.com"); 
              request.setRequestHeader("providers", "prueba");
          },
          //  data: JSON.stringify({id : 1,name:"name"}),
            success: function (result) {
                alert('success');
                console.log(result);
            },
           error: function(result){
                alert('error');
                console.log(result);
              }
        });
    });

  $("#btnPut").click(function () {
        $.ajax({
            url: 'http://stage.etoolapps.com/candystore2/v1/providers',
            type: 'PUT',
            contentType: "application/json; charset=utf-8",
           // dataType: "json",
            beforeSend : function(request) {

              request.setRequestHeader("Authorization", "Basic ;) .");
              request.setRequestHeader("MyCustomHeader", "MyCustomHeader.");
              request.setRequestHeader("Access-Control-Allow-Origin", "http://stage.etoolapps.com"); 
              request.setRequestHeader("providers", "prueba");

          },
            data: JSON.stringify({  
              id: 1,
              name:"Manuel Hernandez",
              phone: "228563417",
              email: "mahernandez@gmail.com",
              idAddress: 1
            }),
            success: function (result) {
                alert('success');
                console.log(result);
            },
          error: function(result) {
                alert('error');
                console.log(result);
            }
        });
    });

   $("#btnDelete").click(function () {
        $.ajax({
            url: 'http://stage.etoolapps.com/candystore2/v1/providers/',
            type: 'DELETE',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend : function(request) {

              request.setRequestHeader("Authorization", "Basic ;) .");
              request.setRequestHeader("MyCustomHeader", "MyCustomHeader.");
              request.setRequestHeader("Access-Control-Allow-Origin", "http://stage.etoolapps.com"); 
              request.setRequestHeader("providers", "prueba");
          },
            data: JSON.stringify({id : 1}),
            success: function (result) {
                alert('success');
                console.log(result);
            },
          error: function(result) {
                alert('error');
                console.log(result);
            }
        });
    });
});