package com.candystore.rest.resource;
import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.Matchers;
import org.mockito.runners.MockitoJUnitRunner;
import java.lang.reflect.Field;
import org.mockito.internal.util.reflection.FieldSetter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import java.util.List;

import com.candystore.rest.model.Order;
import com.candystore.rest.service.OrderService;
import com.candystore.rest.resource.OrderResource;

@RunWith(MockitoJUnitRunner.class)
public class OrderResourceTest {
	private OrderService orderService;
  private OrderResource orderResource;
  private Order order;
  private HttpHeaders header;
  
  @Before
  public void setUp(){ 
     orderResource = new OrderResource();
     orderService = Mockito.mock(OrderService.class);  
     order = Mockito.mock(Order.class);
     header = Mockito.mock(HttpHeaders.class);
    List list=Mockito.mock(List.class);
     Mockito.when(header.getRequestHeader("idClaim")).thenReturn(list);
    Mockito.when(list.get(0)).thenReturn("prueba");
        try
        {
          Field fieldService =  orderResource.getClass().getDeclaredField("service");
          new FieldSetter(orderResource, fieldService).set(orderService);
        }
        catch(NoSuchFieldException e)
        { 
          Assert.fail("failure");
        }
        catch(SecurityException e)
        {
          Assert.fail("failure");
        } 
       
        Mockito.when(order.getIdOrder()).thenReturn(1);		
	      Mockito.when(order.getIdUser()).thenReturn(1);
	      Mockito.when(order.getTotal()).thenReturn(10.00D);		  
	      Mockito.when(order.getStatus()).thenReturn(1);
  }
  
	@Test
	public void resourceCreateOrderSuccesTest() {
      Mockito.when(orderService.createOrder(Matchers.any(Order.class))).thenReturn(order);
      Response response = orderResource.createOrder(header, order);
      System.out.println(">resourceCreateOrderSuccesTest response <   "+response.getStatus());
      Assert.assertNotNull(response);
      Assert.assertEquals(200,response.getStatus());    
	}
  @Test
	public void resourceCreateOrderFailTest() {	
      Mockito.when(orderService.createOrder(order)).thenReturn(order);
      Mockito.when(header.getRequestHeader("idClaim").get(0)).thenReturn("error");
      Response response = orderResource.createOrder(header, order);
      System.out.println(">resourceCreateOrderSuccesTest response <   "+response.getStatus());
      Assert.assertNotNull(response);
      Assert.assertEquals(404,response.getStatus());    
	}
  
  
	
	@Test
	public void resourceGetOrderSuccesTest() {		
      Mockito.when(orderService.getOrder(1)).thenReturn(order);
      Response response = orderResource.getOrder(header,1);
      System.out.println(">resourceGetOrderTest response <   "+response.getStatus());
      Assert.assertNotNull(response);
      Assert.assertEquals(200,response.getStatus());    
	}
	@Test
	public void resourceGetOrderFailTest() {		
      Mockito.when(header.getRequestHeader("idClaim").get(0)).thenReturn("error");
      Mockito.when(orderService.getOrder(1)).thenReturn(order);
      Response response = orderResource.getOrder(header,1);
      System.out.println(">resourceGetOrderTest response <   "+response.getStatus());
      Assert.assertNotNull(response);
      Assert.assertEquals(404,response.getStatus());    
	}
  
  
  
	@Test
	public void resourceUpdateOrderSuccesTest() {
      Mockito.when(orderService.updateOrder(order)).thenReturn(true);
      Response response = orderResource.updateOrder(header, order);
      System.out.println(">resourceUpdateOrderTest response <   "+response.getStatus());
      Assert.assertNotNull(response);
      Assert.assertEquals(200,response.getStatus());   
	}
  @Test
	public void resourceUpdateOrderFailTest() {
      Mockito.when(header.getRequestHeader("idClaim").get(0)).thenReturn("error");
      Mockito.when(orderService.updateOrder(order)).thenReturn(true);
      Response response = orderResource.updateOrder(header, order);
      System.out.println(">resourceUpdateOrderTest response <   "+response.getStatus());
      Assert.assertNotNull(response);
      Assert.assertEquals(404,response.getStatus());   
	}
  
  
	
	@Test
	public void resourceDeleteOrderSuccesTest() {		 	    
      Mockito.when(orderService.deleteOrder(1)).thenReturn(true);
      Response response = orderResource.deleteOrder(header,1);
      System.out.println(">resourceDeleteOrderTest response <   "+response.getStatus());
      Assert.assertNotNull(response);
      Assert.assertEquals(200,response.getStatus());   
	}
  @Test
	public void resourceDeleteOrderFailTest() {		 	    
      Mockito.when(header.getRequestHeader("idClaim").get(0)).thenReturn("error");
      Mockito.when(orderService.deleteOrder(1)).thenReturn(true);
      Response response = orderResource.deleteOrder(header,1);
      System.out.println(">resourceDeleteOrderTest response <   "+response.getStatus());
      Assert.assertNotNull(response);
      Assert.assertEquals(404,response.getStatus());   
	}   //*/

}