package com.candystore.rest.service;

import static org.junit.Assert.*;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Test;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.Matchers;

import java.lang.reflect.Field;

import com.candystore.rest.dao.CandyDao;
import com.candystore.rest.model.Candy;
import com.candystore.rest.service.CandyService;

@RunWith(MockitoJUnitRunner.class) 
public class CandyServiceTest {
  
  private CandyDao candyDao;
  private CandyService candyService;
  private Candy candy;
  private int idPrueba;

  @Before
  public void setUp() 
  {
    
    candyService = new CandyService();    
    candy = Mockito.mock(Candy.class);
    candyDao  = Mockito.mock(CandyDao.class);
    
    
    try{
      Field fieldDao = candyService.getClass().getDeclaredField("candyDao");
      new FieldSetter(candyService, fieldDao).set(candyDao);
    }
    catch(NoSuchFieldException e)
    { 
      Assert.fail("failure");
    }
    catch(SecurityException e)
    {
      Assert.fail("failure");
    } 
    
  }
  
  @Test
  public void serviceGetAllCandiesTestSuccess() 
  {
    ArrayList<Candy> candies = new ArrayList<Candy>();
    Mockito.when(candyDao.getAll()).thenReturn(candies); //Matchers 
    System.out.println("Inicio de serviceGetAllCandiesSuccess");
    Response response=candyService.getAllCandies();
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(200, response.getStatus());
  }
  
  @Test
  public void serviceGetAllCandiesTestFail() 
  {
    ArrayList<Candy> candies = new ArrayList<Candy>();
    Mockito.when(candyDao.getAll()).thenReturn(null); //Matchers 
    System.out.println("Inicio de serviceGetAllCandiesFail");
    Response response=candyService.getAllCandies();
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(400, response.getStatus());
  }
  
  @Test
  public void serviceSearchCandyTestSuccess() 
  {  
    int id=0;
    Mockito.when(candyDao.get(Matchers.anyInt())).thenReturn(candy); //Matchers 
    System.out.println("Inicio de serviceSearchCandyTestSuccess");
    Response response=candyService.searchCandy(id);
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(200, response.getStatus());
  }  
  
  @Test
  public void serviceSearchCandyTestFail() 
  {  
    int id=0;
    Mockito.when(candyDao.get(Matchers.anyInt())).thenReturn(null); //Matchers 
    System.out.println("Inicio de serviceSearchCandyTestFail");
    Response response=candyService.searchCandy(id);
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(400, response.getStatus());
  }
  
	@Test
  public void serviceAddCandyTestSuccess() 
  {  
    Mockito.when(candyDao.add(Matchers.any(Candy.class))).thenReturn(true); 
    System.out.println("Inicio de serviceAddCandyTestSuccess");
    Candy candy=new Candy();
    Response response=candyService.addCandy(candy);
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(201, response.getStatus());
  }
  
  @Test
  public void serviceAddCandyTestBadRequest() 
  {
    Mockito.when(candyDao.add(Matchers.any(Candy.class))).thenReturn(false); 
    System.out.println("Inicio de serviceAddCandyTestFail");
    Candy candy=new Candy();
    Response response=candyService.addCandy(candy);
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(400, response.getStatus());
  }
  
  @Test
  public void serviceSetCandyTestSuccess() 
  {
    int id=1;
    Mockito.when(candyDao.update(Matchers.anyInt(),Matchers.any(Candy.class))).thenReturn(true);
    System.out.println("Inicio de serviceSetCandyTestSuccess");
    Candy candy=new Candy();
    Response response=candyService.setCandy(id, candy);
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(202, response.getStatus());
  }
  
  @Test
  public void serviceSetCandyTestFail() 
  {
    int id=1;
    Mockito.when(candyDao.update(Matchers.anyInt(),Matchers.any(Candy.class))).thenReturn(false);
    System.out.println("Inicio de serviceSetCandyTestFail");
    Candy candy=new Candy();
    Response response=candyService.setCandy(id, candy);
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(400, response.getStatus());
  }
  
  @Test
  public void serviceDeleteCandyTestSuccess() 
  {
    int id=1;
    Mockito.when(candyDao.delete(Matchers.anyInt())).thenReturn(true);
    System.out.println("Inicio de serviceDeleteCandyTestSuccess");
    Response response=candyService.deleteCandy(id);
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(200, response.getStatus());
  }
  
  @Test
  public void serviceDeleteCandyTestFail() 
  {
    int id=1;
    Mockito.when(candyDao.delete(Matchers.anyInt())).thenReturn(false);
    System.out.println("Inicio de serviceDeleteCandyTestFail");
    Response response=candyService.deleteCandy(id);
    
    System.out.println("> response <   "+response.getStatus());
    
    Assert.assertNotNull(response);
    Assert.assertEquals(500, response.getStatus());
  }
  
  

}
