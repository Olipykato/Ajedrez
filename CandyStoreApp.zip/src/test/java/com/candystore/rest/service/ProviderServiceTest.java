package com.candystore.rest.service;

import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import java.lang.reflect.Field;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.Matchers;
import com.candystore.rest.dao.ProviderDAO;
import com.candystore.rest.service.ProviderService;
import com.candystore.rest.model.Provider;
import org.junit.Before;
import org.junit.Test;
import org.junit.Assert;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


@RunWith(MockitoJUnitRunner.class) 
public class ProviderServiceTest
{
  private ProviderDAO providerDAO;
  private ProviderService providerService;
  private Provider provider;
  
  @Before 
  public void setUp()
  {
    providerService = new ProviderService();
    provider = Mockito.mock(Provider.class);
    providerDAO = Mockito.mock(ProviderDAO.class);
    
          
    try{
      Field fieldDAO = providerService.getClass().getDeclaredField("providerDao");
      new FieldSetter(providerService, fieldDAO).set(providerDAO);
    }
    catch(NoSuchFieldException e)
    { 
      Assert.fail("failure");
    }
    catch(SecurityException e)
    {
      Assert.fail("failure");
    } 
      
  }

  @Test
  public void serviceCreateProviderSuccessTest() 
  {  
    Mockito.when(providerDAO.createProvider(Matchers.any(Provider.class))).thenReturn(null); 
    
    System.out.println("serviceCreateProviderTest");
    Provider provider = new Provider();
    Response response = providerService.createProvider(provider);
    System.out.println("> response <   "+response.getStatus());
    Assert.assertNotNull(response);
    Assert.assertEquals(Status.CREATED.getStatusCode(),response.getStatus());
  }

   @Test
  public void serviceCreateProviderErrorTest() 
  {  
    Mockito.when(providerDAO.createProvider(Matchers.any(Provider.class))).thenReturn("Error");
    
    System.out.println("serviceCreateProviderTest");
    Provider provider = new Provider();
    Response response = providerService.createProvider(provider);
    System.out.println("> response <   "+response.getStatus());
    Assert.assertNotNull(response);
    Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(),response.getStatus());
  }
  
  
  @Test
  public void serviceUpdateProviderSuccessTest() 
  {  
    Mockito.when(providerDAO.updateProvider(Matchers.any(Provider.class))).thenReturn(true); 
    
    System.out.println("serviceUpdateProviderTest");
    Provider provider = new Provider();
    Response response = providerService.updateProvider(provider);
    System.out.println("> response <   "+response.getStatus());
    Assert.assertNotNull(response);
    Assert.assertEquals(Status.OK.getStatusCode(),response.getStatus());
  }
  
  @Test
  public void serviceUpdateProviderErrorTest() 
  {  
    Mockito.when(providerDAO.updateProvider(Matchers.any(Provider.class))).thenReturn(false);
    
    System.out.println("serviceUpdateProviderTest");
    Provider provider = new Provider();
    Response response = providerService.updateProvider(provider);
    System.out.println("> response <   "+response.getStatus());
    Assert.assertNotNull(response);
    Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(),response.getStatus());
  }
  
}
