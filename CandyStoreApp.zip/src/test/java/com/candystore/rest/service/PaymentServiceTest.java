package com.candystore.rest.service;


import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import com.candystore.rest.model.Payment;
import com.candystore.rest.model.PaymentType;
import com.candystore.rest.service.PaymentService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import java.lang.reflect.Field;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.Matchers;
import com.candystore.rest.dao.PaymentDao;
import com.candystore.rest.helper.PaymentHelper;
import com.candystore.rest.model.Payment;


@RunWith(MockitoJUnitRunner.class)
public class PaymentServiceTest 
{
  
  private PaymentDao paymentDao;
	private PaymentHelper paymentHelper ;
  private PaymentService paymentService;
  private Payment payment;

  @Before
  public void setUp() 
  {
    
    paymentService = new PaymentService();    
    payment = Mockito.mock(Payment.class);
    paymentDao  = Mockito.mock(PaymentDao.class);
    paymentHelper = Mockito.mock(PaymentHelper.class);
    
    try{
      Field fieldDao = paymentService.getClass().getDeclaredField("paymentDao");
      new FieldSetter(paymentService, fieldDao).set(paymentDao);
      Field fieldHelper = paymentService.getClass().getDeclaredField("paymentHelper");
      new FieldSetter(paymentService, fieldHelper).set(paymentHelper);
    }
    catch(NoSuchFieldException e)
    { 
      Assert.fail("failure");
    }
    catch(SecurityException e)
    {
      Assert.fail("failure");
    } 
  
    Mockito.when(paymentHelper.isValidPayment(Matchers.any(Payment.class),Matchers.anyBoolean())).thenReturn(true); //??
    Mockito.when(paymentDao.add(Matchers.any(Payment.class))).thenReturn(null); //??
 
  }

  @Test
  public void serviceCreatePaymentSuccessTest() 
  {  
    Mockito.when(paymentHelper.isValidPayment(Matchers.any(Payment.class),Matchers.anyBoolean())).thenReturn(true); //??
    Mockito.when(paymentDao.add(Matchers.any(Payment.class))).thenReturn(null); //??
    
    System.out.println(">>>>Hello<<<<<  serviceCreatePaymentTest ");
    Payment payment=new Payment();
    Response response=paymentService.createPayment(payment);
    System.out.println("> response <   "+response.getStatus());
    Assert.assertNotNull(response);
    Assert.assertEquals(201,response.getStatus());
 
  }
  
  @Test
  public void serviceCreatePaymentClientErrorTest() 
  {  
    Mockito.when(paymentHelper.isValidPayment(Matchers.any(Payment.class),Matchers.anyBoolean())).thenReturn(false); //??
    Mockito.when(paymentDao.add(Matchers.any(Payment.class))).thenReturn(null); //??
    
    System.out.println(">>>>Hello<<<<<  serviceCreatePaymentTest ");
    Payment payment=new Payment();
    Response response=paymentService.createPayment(payment);
    System.out.println("> response <   "+response.getStatus());
    Assert.assertNotNull(response);
    Assert.assertEquals(400,response.getStatus());
 
  }
 
}