package com.candystore.rest.service;
import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.Matchers;
import org.mockito.runners.MockitoJUnitRunner;
import java.lang.reflect.Field;
import org.mockito.internal.util.reflection.FieldSetter;

import com.candystore.rest.model.Order;
import com.candystore.rest.service.OrderService;
import com.candystore.rest.dao.OrderDAO;

@RunWith(MockitoJUnitRunner.class)
public class OrderServiceTest {
	private OrderService orderService;
  private Order order;
  private OrderDAO orderDao;
  
  @Before
  public void setUp(){ 
      orderService = new OrderService();
      orderDao = Mockito.mock(OrderDAO.class);     
      order = Mockito.mock(Order.class);
        try
        {
            Field fieldDao =  orderService.getClass().getDeclaredField("orderDao");
            new FieldSetter(orderService, fieldDao).set(orderDao);
        }
        catch(NoSuchFieldException e)
        { 
            Assert.fail("failure");
        }
        catch(SecurityException e)
        {
            Assert.fail("failure");
        } 

      Mockito.when(order.getIdOrder()).thenReturn(1);		
      Mockito.when(order.getIdUser()).thenReturn(1);
      Mockito.when(order.getTotal()).thenReturn(10.00D);		  
      Mockito.when(order.getStatus()).thenReturn(1);
  }
  
	@Test
	public void serviceCreateOrderSuccesTest() {		  
      Mockito.when(orderDao.createOrder(Matchers.any(Order.class))).thenReturn(true);
      Assert.assertEquals(order, orderService.createOrder(order));
	}
  @Test
	public void serviceCreateOrderFailTest() {		  
      Mockito.when(orderDao.createOrder(Matchers.any(Order.class))).thenReturn(false);
      Assert.assertNull(orderService.createOrder(order));
	}
  
  
	
	@Test
	public void serviceGetOrderSuccesTest() {		
      Mockito.when(orderDao.getOrder(Matchers.anyInt())).thenReturn(order);
      int idOrder = orderService.getOrder(1).getIdOrder();
      Assert.assertEquals( 1, idOrder);
	}
  @Test
	public void serviceGetOrderFailTest() {		
      Mockito.when(orderDao.getOrder(Matchers.anyInt())).thenReturn(null);
      Assert.assertNull(orderService.getOrder(1));
	}
  
  
	
	@Test
	public void serviceUpdateOrderSuccesTest() {
      Mockito.when(orderDao.updateOrder(Matchers.any(Order.class))).thenReturn(true);
      Assert.assertTrue(orderService.updateOrder(order));
	}
  @Test
	public void serviceUpdateOrderFailTest() {
      Mockito.when(orderDao.updateOrder(Matchers.any(Order.class))).thenReturn(false);
      Assert.assertTrue(!orderService.updateOrder(order));
	}
  
  
	
	@Test
	public void serviceDeleteOrderSuccesTest() {		 	    
      Mockito.when(orderDao.deleteOrder(Matchers.anyInt())).thenReturn(true);
		  Assert.assertTrue(orderService.deleteOrder(1));
	}
  @Test
	public void serviceDeleteOrderFailTest() {		 	    
      Mockito.when(orderDao.deleteOrder(Matchers.anyInt())).thenReturn(false);
		  Assert.assertTrue(!orderService.deleteOrder(1));
	}
}