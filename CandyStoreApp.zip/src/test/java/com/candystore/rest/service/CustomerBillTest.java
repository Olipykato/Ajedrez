package com.candystore.rest.service;

import static org.mockito.Mockito.when;
 
import java.util.ArrayList;
import java.util.List;
 
import com.candystore.rest.model.Customer;
import com.candystore.rest.dao.daoInterface.Item;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class) 
public class CustomerBillTest {
  
  private Customer customer;
  
  @Before
  public void setUp() {
    customer = new Customer();
    customer.setName("Carolina");
    List<Item> items = new ArrayList<>();
    
    Item item1 = Mockito.mock(Item.class);
    Item item2 = Mockito.mock(Item.class);
    Item item3 = Mockito.mock(Item.class);
    
    items.add(item1);
    items.add(item2);
    items.add(item3);
    
    customer.setListOfItems(items);
    
    when(item1.getName()).thenReturn("Rice");
    when(item2.getName()).thenReturn("Tea");
    when(item3.getName()).thenReturn("Wheat");
    
    when(item1.getPrice("Rice")).thenReturn(100);
    when(item2.getPrice("Tea")).thenReturn(200);
    when(item3.getPrice("Wheat")).thenReturn(300);
  }
  
  @Test
  public void customerCalculateBillTest() {
    int billAmount = customer.calculateBill();
    Assert.assertEquals(600, billAmount);
  }
  
}