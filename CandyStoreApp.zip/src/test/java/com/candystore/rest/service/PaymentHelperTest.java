package com.candystore.rest.service;

import static org.mockito.Mockito.when;
 
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
 
import com.candystore.rest.model.Payment;
import com.candystore.rest.model.PaymentType;
import com.candystore.rest.helper.PaymentHelper;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.Ignore;
import org.junit.runner.RunWith;

import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PaymentHelperTest {
  
  private PaymentHelper paymentHelper;
  private Payment payment;
  
  @Before
  public void setUp() {
    paymentHelper = new PaymentHelper();
    payment = Mockito.mock(Payment.class);
    
    /*
    when(payment.getId()).thenReturn(1);
    when(payment.getCardNumber()).thenReturn("1234567890123");
    when(payment.getMonth()).thenReturn(9);
    when(payment.getYear()).thenReturn(2020);
    when(payment.getCvc()).thenReturn(123);
    when(payment.getNameInCard()).thenReturn("Ruddy Garcia");
    when(payment.getIdPaymentType()).thenReturn(PaymentType.CREDIT_CARD);  
    */
    
    when(payment.getId()).thenReturn(1);
    when(payment.getCardNumber()).thenReturn("1234567890123456");
    when(payment.getMonth()).thenReturn(13);
    when(payment.getYear()).thenReturn(1900);
    when(payment.getCvc()).thenReturn(1234);
    when(payment.getNameInCard()).thenReturn("Diana Noria");
    when(payment.getIdPaymentType()).thenReturn(8);    
  }
  
  @Ignore
  @Test
  public void isValidPaymentWithIdTest() {
    Assert.assertTrue(paymentHelper.isValidPayment(payment, true));
  }
  
  @Ignore
  @Test
  public void isValidPaymentWithoutIdTest() {
    Assert.assertTrue(paymentHelper.isValidPayment(payment, false));
  }
  
  @Ignore
  @Test
  public void isInvalidPayment() {
    Assert.assertFalse(paymentHelper.isValidPayment(payment, true));
  }
  
}