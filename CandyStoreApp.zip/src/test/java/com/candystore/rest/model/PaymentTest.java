package com.candystore.rest.model;

import static org.mockito.Mockito.when;
 
import com.candystore.rest.model.Address;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.Ignore;
import org.junit.runner.RunWith;

import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class) 
public class PaymentTest {

	private Payment payment; 
  
  @Before
  public void setUp() {
    payment = Mockito.mock(Payment.class);
    
    when(payment.getId()).thenReturn(1);
    when(payment.getCardNumber()).thenReturn("1234567890123");
    when(payment.getMonth()).thenReturn(9);
    when(payment.getYear()).thenReturn(2020);
    when(payment.getCvc()).thenReturn(123);
    when(payment.getNameInCard()).thenReturn("Ruddy Garcia");
    when(payment.getIdPaymentType()).thenReturn(PaymentType.CREDIT_CARD);  
  }
  
  @Test
  public void validPaymentTest() {
    Assert.assertEquals(1, (int) payment.getId());
    Assert.assertEquals("1234567890123", payment.getCardNumber());
    Assert.assertEquals(9, (int) payment.getMonth());
    Assert.assertEquals(2020, (int) payment.getYear());
    Assert.assertEquals(123, (int) payment.getCvc());
    Assert.assertEquals("Ruddy Garcia", payment.getNameInCard());
    Assert.assertEquals(PaymentType.CREDIT_CARD, (int) payment.getIdPaymentType());
  }
  
}
