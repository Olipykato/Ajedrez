package com.candystore.rest.model;

import static org.mockito.Mockito.when;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
 
import com.candystore.rest.model.Order;

@RunWith(MockitoJUnitRunner.class) 
public class OrderTest {

	private Order order; 
  
  @Before
  public void setUp() {
    order = Mockito.mock(Order.class);    
    when(order.getIdOrder()).thenReturn(1);
    when(order.getIdUser()).thenReturn(1);
    when(order.getTotal()).thenReturn(10.00);
    when(order.getStatus()).thenReturn(1); 
  }
  
  @Test
  public void validOrderTest() {
    
    int aux = order.getIdOrder();
    Assert.assertEquals(1, aux);
    
    aux = order.getIdUser();
    Assert.assertEquals(1, aux);
    
    double delta = 1e-15;
    Assert.assertEquals(10.00, order.getTotal(),delta);
    
    aux = order.getStatus();
    Assert.assertEquals(1, aux);
  }
  
}
