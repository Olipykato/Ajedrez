package com.candystore.rest.model;

import static org.mockito.Mockito.when;
import com.candystore.rest.model.Address;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import com.candystore.rest.model.Address;


/*@RunWith(MockitoJUnitRunner.class) 
public class AddressTest
{
  Address address;
  
  @Before
  public void setUp() {
    address = Mockito.mock(Address.class);    
    Mockito.when(address.getId()).thenReturn(17); //??
    Mockito.when(address.getStreet()).thenReturn("street"); //??
    Mockito.when(address.getCity()).thenReturn("city"); //??
  }
  
  @Test
  public void testAddress() 
  {
    Assert.assertEquals(17, address.getId());
    Assert.assertEquals("city", address.getCity());
    Assert.assertEquals("street", address.getStreet());
  }

}*/

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.junit.Ignore;
import org.junit.runner.RunWith;

@RunWith(MockitoJUnitRunner.class)
public class AddressTest {
  
  private Address address;
  
  @Before
  public void setUp() {
    address = Mockito.mock(Address.class); 
    
    when(address.getId()).thenReturn(5);
    when(address.getStreet()).thenReturn("Argentina");
    when(address.getExteriorNumber()).thenReturn("225");
    when(address.getInteriorNumber()).thenReturn(null);
    when(address.getCity()).thenReturn("Celaya");
    when(address.getState()).thenReturn("Guanajuato");
    when(address.getZipCode()).thenReturn("38022");
  }
  
  @Test
  public void validAddressTest() {
    Assert.assertEquals(5, address.getId());
    Assert.assertEquals("Argentina", address.getStreet());
    Assert.assertEquals("225", address.getExteriorNumber());
    Assert.assertEquals(null, address.getInteriorNumber());
    Assert.assertEquals("Celaya", address.getCity());
    Assert.assertEquals("Guanajuato", address.getState());
    Assert.assertEquals("38022", address.getZipCode());
  }
}    
