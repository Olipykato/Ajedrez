package com.candystore.rest.model;

//import org.mockito.Mockito.*;

import java.util.List;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.candystore.rest.model.Candy;

@RunWith(MockitoJUnitRunner.class) 
public class CandyModelTest {

	Candy candy;

  @Before
	public void setUp() {
    candy = Mockito.mock(Candy.class);
    Mockito.when(candy.getId()).thenReturn(19);
    Mockito.when(candy.getName()).thenReturn("Snickers");
    Mockito.when(candy.getDescription()).thenReturn("Con cacahuate");
    Mockito.when(candy.getPrice()).thenReturn(19.50D);
	}
  
  @Test
  public void initTest() {
      Assert.assertEquals(19, candy.getId());
      Assert.assertEquals("Snickers", candy.getName());
      Assert.assertEquals("Con cacahuate", candy.getDescription());
      //Assert.assertEquals(19.50D, candy.getPrice());
   }

  
  

	

}
