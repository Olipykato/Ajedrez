package com.candystore.rest.model;
import com.candystore.rest.model.Provider;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class) 
public class ProviderTest 
{
  Provider provider;
  
  @Before
  public void setUp()
  {
    provider = Mockito.mock(Provider.class);
    Mockito.when(provider.getId()).thenReturn(1);
    Mockito.when(provider.getName()).thenReturn("Sharon Irais");
    Mockito.when(provider.getEmail()).thenReturn("sharonirais@gmail.com");
    Mockito.when(provider.getPhone()).thenReturn("2282856476");
    Mockito.when(provider.getIdAddress()).thenReturn(1);  
  }
  
  @Test
  public void testProvider()
  {
    Assert.assertEquals(1, (int) (provider.getId()));
    Assert.assertEquals("Sharon Irais", provider.getName());
    Assert.assertEquals("sharonirais@gmail.com", provider.getEmail());
    Assert.assertEquals("2282856476", provider.getPhone());
    Assert.assertEquals(1, (int) provider.getIdAddress());
  }
    
    
}
